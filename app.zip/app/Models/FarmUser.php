<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FarmUser extends Model
{
    //
    protected $table = 'farm_user';
    protected $guarded = [];

}
